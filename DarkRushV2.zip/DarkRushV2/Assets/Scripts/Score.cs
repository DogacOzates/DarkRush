﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class Score : MonoBehaviour
{
    public static float scoreValue = 0;
    Text score;
    public GameObject pausePanel;
    public GameObject winPanel;

    void Start()
    {
        score = GetComponent<Text>();
    }

    
    void Update()
    {
        if (Player.gameIsPaused == true)
        {
            scoreValue = scoreValue + 0.0f * Time.deltaTime;
        }
        else if (Player.gameIsPaused == false)
        {
            
                scoreValue = scoreValue + 0.5f * Time.deltaTime;
            
        }

        if (scoreValue >= 100.0f)
        {
            scoreValue = 0;
           
            winPanel.SetActive(true);
            Invoke("quitgame", 2.0f);
            Time.timeScale = 0;

        }

        score.text = "Score : " + scoreValue.ToString("0");
    }
     
}
