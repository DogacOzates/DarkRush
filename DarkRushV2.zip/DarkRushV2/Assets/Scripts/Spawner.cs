﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject goSpawn;
    public float fDifficulty;
    float fSpawn;

    void FixedUpdate()
    {
        if (Player.gameIsPaused != true)
        {
            if (fDifficulty < 200)
            {
                fSpawn += fDifficulty * Time.deltaTime;
               
                    fDifficulty += 2f * Time.deltaTime;
                
               
            }
           
            else if (fDifficulty >= 200)
            {
                fSpawn += fDifficulty * Time.deltaTime;
                
                    fDifficulty += 1f * Time.deltaTime;
                
                   
            }

            while (fSpawn > 0)
            {
                fSpawn -= 1;
                Vector3 v3Pos = transform.position + new Vector3(Random.value * 50 - 30f, 5, Random.value * 50 - 30f);
                Quaternion qRot = Quaternion.Euler(0, Random.value * 360f, Random.value * 30f);
                Vector3 v3Scale = new Vector3(Random.value + 0.1f, 10f, Random.value + 0.1f);
                GameObject goCreated = Instantiate(goSpawn, v3Pos, qRot);
                goCreated.transform.localScale = v3Scale;
            }
        }

       
    }
}
