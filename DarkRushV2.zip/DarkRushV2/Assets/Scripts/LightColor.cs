﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightColor : MonoBehaviour
{
      float duration = 50.0f;
    Color color0 = Color.red;
    Color color1 = Color.blue;

    Light lt;

    void Start()
    {
        lt = GetComponent<Light>();
    }

    void Update()
    {
      
        float t1 = Mathf.PingPong(Time.time, duration) / duration;

        lt.color = Color.Lerp(color0, color1, t1);
    }
}
