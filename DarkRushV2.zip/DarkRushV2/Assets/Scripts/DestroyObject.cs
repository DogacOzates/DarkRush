﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyObject : MonoBehaviour
{
   
    void Start()
    {
        if (Player.gameIsPaused != true)
            Destroy(gameObject, 6.0f);
    }
}
