﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class Player : MonoBehaviour
{

    Rigidbody rigid;
    Collider m_ObjectCollider;
    public GameObject pausePanel;
    public Image image;
    public static bool TrigerCheck=false;
    private bool gameStart = false;
    public static bool gameIsPaused = false;

   
    public static float timeSave;

    public Text timer;
    public float startTime = 3.0f;
    float currentTime = 0f;

    // Use this for initialization
    void Start()
    {
        currentTime = startTime;
        m_ObjectCollider = GetComponent<Collider>();
        m_ObjectCollider.isTrigger = true;
        rigid = GetComponent<Rigidbody>();
        Invoke("StartGame", 3.0f);
        
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        
               
            if (gameStart == true)
            {
                if (gameIsPaused != true)
                {

                        Trigerfalse();

                        transform.rotation *= Quaternion.Euler(0, 0, 5 * Time.deltaTime);
                        Time.timeScale += Time.fixedDeltaTime * 0.005f;

                        rigid.velocity += transform.rotation * (Vector3.right * SimpleInput.GetAxisRaw("Horizontal") * 10f * Time.deltaTime);
                        rigid.velocity += transform.rotation * (Vector3.up * SimpleInput.GetAxisRaw("Vertical") * 10f * Time.deltaTime);
                    
                }
            }
        

    }

    private void OnCollisionEnter(Collision collision)
    {
        m_ObjectCollider.isTrigger = true;
        PauseGame();
            
    }
    public void TimerCount()
    {

        timer.text = currentTime.ToString("0.0");
        currentTime -= 1*Time.deltaTime;

        if (currentTime <= 0)
        {
            pausePanel.SetActive(false);
            gameIsPaused = false;
            Time.timeScale =timeSave;
           
            TrigerCheck = true;
            currentTime = startTime;

          
        }
    }

    public void StartGame()
    {
        gameStart = true;
    }

 
    public void TrigerTrue()
    {
        m_ObjectCollider.isTrigger = true;
    }
    public void Trigerfalse()
    {
        m_ObjectCollider.isTrigger = false;
    }

    public void RestartGame()
    {
        Debug.Log("RestartGame");
        gameIsPaused = false;
        Time.timeScale = 1f;
        Score.scoreValue = 0;
        pausePanel.SetActive(false);
       
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
       
    }

   public void PauseGame()
   {
       TrigerTrue();
       timeSave = Time.timeScale;
  
       gameIsPaused = true;
       Time.timeScale = 0;
       pausePanel.SetActive(true);
       
    }

}
